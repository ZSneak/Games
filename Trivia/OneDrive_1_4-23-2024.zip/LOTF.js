var GAMERUNNING = true;
var PLACE = 1;

story = {
    1: ["[INSERT DIALOGUE HERE] 1"],
    2: ["[INSERT DIALOGUE HERE] 2"],
    3: ["[INSERT DIALOGUE HERE] 3"],
    4: ["[INSERT DIALOGUE HERE] 4"],
    5: ["[INSERT DIALOGUE HERE] 5"],
    6: ["[INSERT DIALOGUE HERE] 6"],
}
firstoption = {
    1: ["[INSERT first option HERE] 1"],
    2: ["[INSERT first option HERE] 2"],
    3: ["[INSERT first option HERE] 3"],
    4: ["[INSERT first option HERE] 4"],
    5: ["[INSERT first option HERE] 5"],
    6: ["[INSERT first option HERE] 6"],
}

secondoption = {
    1: ["[INSERT second option HERE] 1"],
    2: ["[INSERT second option HERE] 2"],
    3: ["[INSERT second option HERE] 3"],
    4: ["[INSERT second option HERE] 4"],
    5: ["[INSERT second option HERE] 5"],
    6: ["[INSERT second option HERE] 6"],
}

lookup = {
    1.1: [1],
    1.2: [3],
    2.1: ["[INSERT next dio #]"],
    2.2: ["[INSERT next dio #]"],
    3.1: ["[INSERT next dio #]"],
    3.2: ["[INSERT next dio #]"],
    4.1: ["[INSERT next dio #]"],
    4.2: ["[INSERT next dio #]"],
    5.1: ["[INSERT next dio #]"],
    5.2: ["[INSERT next dio #]"],
    6.1: ["[INSERT next dio #]"],
    6.2: ["[INSERT next dio #]"],
}


function main(){
    while (true){
        console.log(story[place]);
        var choosing = true;
        while (choosing){
            var choice = prompt("Would you rather: (A) " + firstoption[PLACE] + ", or (B) " + secondoption[PLACE] + "? :");
            if (choice == "A" || choice == "B" || choice == "a" || choice == "b" || choice == "1" || choice == 2){
                var choosing = False;
            } else {
                console.log("Pease enter a valid numbers");
            }
            if (choice == "A"||choice == "a"){
                var choice = 1;
            } else if (choice == "B"||choice == "b"){
                var choice = 2;
            }
            try {
                var place = lookup[parseFloat(String(place) + "." + String(choice))]
            } catch(Hi){
                error("Please fill out the template");
            }
        }
        
    }
}