var questions = ["What is 1+1", "What is 3+3", "What is 7 - 4"];
var answer_one = [1, 3, 1,];
var answer_two = [2, 6, 7,];
var correct_answer = [2, 2, 2];
var questionNum = 0;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


function onStart(){
    document.getElementById("start").style.display = "none";
    document.getElementById("sOut").style.display = "block";
    document.getElementById("button1").style.display = "block";
    document.getElementById("button2").style.display = "block";
    nextques();
}

function nextques() {
    sOut.textContent = questions[questionNum];
    document.getElementById("button1").textContent = answer_one[questionNum];
    document.getElementById("button2").textContent = answer_two[questionNum];
    if (questions.length == answer_one.length && answer_one.length == answer_two.length && questions.length > questionNum){
        console.log("More ?'s");
    } else {
        console.log("No more ?'s");
        document.getElementById("start").style.display = "none";
        document.getElementById("sOut").style.display = "none";
        document.getElementById("button1").style.display = "none";
        document.getElementById("button2").style.display = "none";
        document.stop();
    }
}

function testcorrectanswer(buttonclick) {
    if (buttonclick == 1 || buttonclick == 2){
        if (buttonclick == correct_answer[questionNum]){
            move("check")
        } else {
            move("x")
        }
    } else {
        console.error("Wierd button clicked");
        stop;
    }
}

async function move(objname) {
    document.getElementById(objname).style.display = "block";
    if (objname == "check") {
        document.getElementById("ding").play();
    } else {
        document.getElementById("beep").play();
    }
    await sleep(2000);
    document.getElementById(objname).style.display = "none";
}

function button1C() {
    console.log("b1c");
    testcorrectanswer(1);
    questionNum++;
    nextques();
}

function button2C() {
    console.log("b2c");
    testcorrectanswer(2);
    questionNum++;
    nextques();
}
